from client import StoreClient, VoldemortException
