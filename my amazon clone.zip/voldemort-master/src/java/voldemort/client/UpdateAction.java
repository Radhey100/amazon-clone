/*
 * Copyright 2008-2009 LinkedIn, Inc
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 * 
 * http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */

package voldemort.client;

/**
 * An update action such as a read-modify-store cycle. This is meant to be used
 * as a callback interface to perform a data modification that might involve
 * obsolete data. The operation will be repeated until it succeeds.
 * 
 * The update action must be idempotent since it may be called multiple times.
 * 
 * 
 */
public abstract class UpdateAction<K, V> {

    /**
     * Apply the update operation to the given store client.
     * 
     * @param storeClient The store client to use
     */
    public abstract void update(StoreClient<K, V> storeClient);

    /**
     * A hook for the user to override with any rollback actions they want
     * performed when the update fails (say due to an exception or due to too
     * many ObsoleteVersionExceptions).
     */
    public void rollback() {}

}
